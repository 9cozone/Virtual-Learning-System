 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>

<?php
	
if(isset($_GET['send'])){
 	$question= mysqli_real_escape_string($con,$_GET['question']);
  	$question_no = mysqli_real_escape_string($con,$_GET['question_no']);
  	$department = mysqli_real_escape_string($con,$_GET['department']);
   	$date = date("y-m-d");
 
 	 
	
	
	if($question!='' && $question_no!='' && $department!=''   ){
				
 

			

		//Inset the value to pin request
		$query = mysqli_query($con,"insert into assignment(`username`,`department`,`question_no`,`question`,`date`) values( '$username','$department','$question_no','$question','$date')");
		if($query){
			echo '<script>alert("Your question  has been sent successfully");window.location.assign("assignment.php");</script>';
		}
		else{
			//echo mysqli_error($con);
			echo '<script>alert("Unknown error occure.");window.location.assign("assignment.php");</script>';
		}
	}
	else{
		echo '<script>alert("Please fill all the fields");</script>';
	}
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VIDEOS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
	<div class="mainbar">
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>           

      </div>
 	       	<table   class="gadget">
                            	<tr>
                                	<th>S.n.</th>
                                    <th>Question No</th>
                                    <th>Department</th>
                                    <th>Question</th>
                                     <th>Date</th>
                                </tr>
                                <?php
									$query = mysqli_query($con,"select * from assignment   ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$question_no = $row['question_no'];
											$department = $row['department'];
											$question = $row['question'];
 											$date = $row['date'];
 										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $question_no; ?></td>
                                                <td><?php echo $department; ?></td>
                                                <td><?php echo $question; ?></td>
                                                  <td><?php echo $date; ?></td>
                                                
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No Assignment Yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>           

       
 <div   class="article">
            <form action="assignment.php" method="GET" id="sendemail">
            <ol>
              <li>
                <label for="number">Question No </label>
                <select   name="question_no" class="text" >
					<option>1.</option>
					<option>2.</option>
					<option>3.</option>
					<option>4.</option>
					<option>5.</option>
					 
				</select>
               </li>
                       <select   name ="department" class="textbox" required>
								<option> ACCIDENT & EMERGENCY</option>
								<option> ACCOUNTANCY</option>
								<option>  ADULT & CONTINUING EDUCATION</option>
								<option> AGRICULTURAL & BIORESOURCE ENGINEERING</option>
								<option> AGRICULTURE ECONOMICS & EXTENSION</option>
								<option>  AGRONOMY & ECOLOGICAL MANAGEMENT </option>
								<option>  ANAESTHOLOGY</option>
								<option> ANATOMY</option>
								<option> ANIMAL/FISHERIES SCIENCE & MANAGEMENT</option>
								<option> APPLIED BIOCHEMISTRY</option>
								<option>  APPLIED BIOLOGY & BIOTECHNOLOGY</option>
								<option> APPLIED MICROBIOLOGY & BREWING</option>
								<option>  BANKING & FINANCE</option>
								<option>  BUILDING</option>
								<option> BUSINESS ADMINISTRATION</option>
								<option>  BUSINESS LAW</option>
								<option> CHEMICAL ENGINEERING</option>
								<option>  CIVIL ENGINEERING</option>
								<option> CLINICAL PHARMACY & BIOPHARMACEUTICS</option>
								<option> COMMUNITY MEDICINE</option>
								<option>  COMPUTER ENGINEERING</option>
								<option>  COMPUTER SCIENCE</option>
								<option>  COORPERATIVE & RURAL DEVELOPMENT</option>
								<option> ECONOMICS</option>
								<option>  EDUCATION FOUNDATION</option>
								<option>  EDUCATION MANAGEMENT</option>
								<option>  ELECTRICAL & ELECTRONICS ENGINEERING</option>
								<option>  ESTATE MANAGEMENT</option>
								<option>  FOOD SCIENCE & TECHNOLOGY</option>
								<option>  GEOGRAPHY & METEOROLOGY</option>
								<option>  GEOLOGY & MINING</option>
								<option>  GUIDANCE & COUNSELLING</option>
								<option> HAEMATOLOGY/IMMUNOLOGY</option>
								<option> HEALTH & PHYSICAL EDUCATION</option>
								<option>  HISTOPATHOLOGY</option>
								<option>  HUMAN PHYSIOLOGY</option>
								<option>  INDUSTRIAL CHEMISTRY</option>
								<option>  INDUSTRIAL MATHEMATICS & APPLIED STATISTICS</option>
								<option> INDUSTRIAL PHYSICS</option>
								<option>  INSURANCE & RISK MANAGEMENT</option>
								<option>  INTERNAL MEDICINE</option>
								<option>  INTERNATIONAL LAW & JURISPRUDENCE</option>
								<option> LIBRARY & INFORMATION SCIENCE</option>
								<option>  MARKETING</option>
								<option>  MASS COMMUNICATION</option>
								<option> MATHEMATICS & COMPUTER EDUCATION</option>
								<option> MECHANICAL & PRODUCTION ENGINEERING</option>
								<option>  MEDICAL BIOCHEMISTRY</option>
								<option>  MEDICAL LABORATORY SCIENCES</option>
								<option>  OBSTETRICS & GYNAECOLOGY</option>
								<option>  OPHTHALMOLOGY</option>
								<option>  ORTOLARYNGOLOGY</option>
								<option> PAEDIATRICS</option>
								<option>  PATHOLOGY</option>
								<option>  PHARMACEUTICAL CHEMISTRY</option>
								<option> PHARMACEUTICS & PHARMACEUTICAL TECHNOLOGY</option>
								<option>  PHARMACOGNOSY</option>
								<option>  PHARMACOLOGY</option>
								<option>  PHARMACOLOGY & THERAPEUTICS</option>
								<option>  POLITICAL SCIENCE</option>
								<option>  PRIVATE & PROPERTY LAW</option>
								<option> PSYCHOLOGY</option>
								<option>  PUBLIC ADMINISTRATION</option>
								<option>  PUBLIC LAW</option>
								<option>  QUANTITY SURVEYING</option>
								<option>  RADIOLOGY</option>
								<option>  SCIENCE & COMPUTER EDUCATION</option>
								<option>  SOCIOLOGY & ANTHROPOLOGY</option>
								<option> SURGERY</option>
								<option> SURVEYING & GEOINFORMATICS</option>
								<option>  TECHNOLOGY & VOCATIONAL EDUCATION</option>
								<option> URBAN & REGIONAL PLANNING</option>
								 
 								</select>	
 
             
              <li>
                <label for="answer">Questions</label>
                <textarea   name="question" rows="8" cols="50"></textarea>
              </li>
              <li>
                <input type="submit" name="send"  value="Submit"  />
               </li>
            </ol>
          </form>
       
		 </div>
		 
	
		 
		 
 