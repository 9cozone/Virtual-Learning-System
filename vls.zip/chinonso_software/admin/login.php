<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
      <div class="content">
    <div class="content_resize">
         <div class="mainbar">
        <div class="article">
          <h2><span>Login</span></h2>
          <div class="clr"></div>
         </div>
        <div class="article">
      
          <form action="pro_log.php" method="POST" id="sendemail">
            <ol>
              <li>
                <label for="name">UserName</label>
                <input id="name" name="username" class="text" />
              </li>
              <li>
                <label for="password">Password</label>
                <input id="email" name="password" class="text" />
              </li>
               
              <li>
                <input type="submit" name="login" style ="width:120px; height:40px; "id="imageField" value="Login" class="send" />
                <div class="clr"></div>
              </li>
            </ol>
          </form>
        </div>
      </div>
    

<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
