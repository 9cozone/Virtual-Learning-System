 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>

<?php
	
if(isset($_GET['send'])){
 	$question_no = mysqli_real_escape_string($con,$_GET['question_no']);
  	$department = mysqli_real_escape_string($con,$_GET['department']);
  	$question = mysqli_real_escape_string($con,$_GET['question']);
  	$option_a = mysqli_real_escape_string($con,$_GET['option_a']);
  	$option_b = mysqli_real_escape_string($con,$_GET['option_b']);
  	$option_c = mysqli_real_escape_string($con,$_GET['option_c']);
  	$correct_option = mysqli_real_escape_string($con,$_GET['correct_option']);
  	$date = date("y-m-d");
 
 	 
	
	
	if($question_no!='' && $department!='' && $question!=''&&  $option_a!='' &&
	$option_b!='' && $option_c!='' && $correct_option!='' 
 	){
				
 

			

		//Inset the value to pin request
		$query = mysqli_query($con,"insert into examination(`username`,`question_no`,`department`,`question`,`option_a`,`option_b`,`option_c`,
		`correct_option`,`date`) values( '$username`','$question_no','$department ',
		'$question','$option_a','$option_b','$option_c','$correct_option','$date')"); 
		if($query){
			echo '<script>alert("Your question  has been sent successfully");window.location.assign("examination.php");</script>';
		}
		else{
			//echo mysqli_error($con);
			echo '<script>alert("Unknown error occure.");window.location.assign("examination.php");</script>';
		}
	}
	else{
		echo '<script>alert("Please fill all the fields");</script>';
	}
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VIDEOS</title>
<?php include('php_include/nav.php');?>
  
	<div  >
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>           

      </div>
 	       
 <div  style="float:left; clear:left; margin-left:5%;" class="content">
            <form action="" method="GET" id="sendemail">
            <ol>
              <li>
                <label for="number">Question No </label>
                <select   name="question_no" class="text" >
					<option>1.</option>
					<option>2.</option>
					<option>3.</option>
					<option>4.</option>
					<option>5.</option>
					<option>6.</option>
					<option>7.</option>
					<option>8.</option>
					<option>9.</option>
					<option>10.</option>
				</select>
               </li>
               <label class="control-label">Department</label>
              <div class="controls">
             						<select   name ="department" class="textbox" required>
								<option> ACCIDENT & EMERGENCY</option>
								<option> ACCOUNTANCY</option>
								<option>  ADULT & CONTINUING EDUCATION</option>
								<option> AGRICULTURAL & BIORESOURCE ENGINEERING</option>
								<option> AGRICULTURE ECONOMICS & EXTENSION</option>
								<option>  AGRONOMY & ECOLOGICAL MANAGEMENT </option>
								<option>  ANAESTHOLOGY</option>
								<option> ANATOMY</option>
								<option> ANIMAL/FISHERIES SCIENCE & MANAGEMENT</option>
								<option> APPLIED BIOCHEMISTRY</option>
								<option>  APPLIED BIOLOGY & BIOTECHNOLOGY</option>
								<option> APPLIED MICROBIOLOGY & BREWING</option>
								<option>  BANKING & FINANCE</option>
								<option>  BUILDING</option>
								<option> BUSINESS ADMINISTRATION</option>
								<option>  BUSINESS LAW</option>
								<option> CHEMICAL ENGINEERING</option>
								<option>  CIVIL ENGINEERING</option>
								<option> CLINICAL PHARMACY & BIOPHARMACEUTICS</option>
								<option> COMMUNITY MEDICINE</option>
								<option>  COMPUTER ENGINEERING</option>
								<option>  COMPUTER SCIENCE</option>
								<option>  COORPERATIVE & RURAL DEVELOPMENT</option>
								<option> ECONOMICS</option>
								<option>  EDUCATION FOUNDATION</option>
								<option>  EDUCATION MANAGEMENT</option>
								<option>  ELECTRICAL & ELECTRONICS ENGINEERING</option>
								<option>  ESTATE MANAGEMENT</option>
								<option>  FOOD SCIENCE & TECHNOLOGY</option>
								<option>  GEOGRAPHY & METEOROLOGY</option>
								<option>  GEOLOGY & MINING</option>
								<option>  GUIDANCE & COUNSELLING</option>
								<option> HAEMATOLOGY/IMMUNOLOGY</option>
								<option> HEALTH & PHYSICAL EDUCATION</option>
								<option>  HISTOPATHOLOGY</option>
								<option>  HUMAN PHYSIOLOGY</option>
								<option>  INDUSTRIAL CHEMISTRY</option>
								<option>  INDUSTRIAL MATHEMATICS & APPLIED STATISTICS</option>
								<option> INDUSTRIAL PHYSICS</option>
								<option>  INSURANCE & RISK MANAGEMENT</option>
								<option>  INTERNAL MEDICINE</option>
								<option>  INTERNATIONAL LAW & JURISPRUDENCE</option>
								<option> LIBRARY & INFORMATION SCIENCE</option>
								<option>  MARKETING</option>
								<option>  MASS COMMUNICATION</option>
								<option> MATHEMATICS & COMPUTER EDUCATION</option>
								<option> MECHANICAL & PRODUCTION ENGINEERING</option>
								<option>  MEDICAL BIOCHEMISTRY</option>
								<option>  MEDICAL LABORATORY SCIENCES</option>
								<option>  OBSTETRICS & GYNAECOLOGY</option>
								<option>  OPHTHALMOLOGY</option>
								<option>  ORTOLARYNGOLOGY</option>
								<option> PAEDIATRICS</option>
								<option>  PATHOLOGY</option>
								<option>  PHARMACEUTICAL CHEMISTRY</option>
								<option> PHARMACEUTICS & PHARMACEUTICAL TECHNOLOGY</option>
								<option>  PHARMACOGNOSY</option>
								<option>  PHARMACOLOGY</option>
								<option>  PHARMACOLOGY & THERAPEUTICS</option>
								<option>  POLITICAL SCIENCE</option>
								<option>  PRIVATE & PROPERTY LAW</option>
								<option> PSYCHOLOGY</option>
								<option>  PUBLIC ADMINISTRATION</option>
								<option>  PUBLIC LAW</option>
								<option>  QUANTITY SURVEYING</option>
								<option>  RADIOLOGY</option>
								<option>  SCIENCE & COMPUTER EDUCATION</option>
								<option>  SOCIOLOGY & ANTHROPOLOGY</option>
								<option> SURGERY</option>
								<option> SURVEYING & GEOINFORMATICS</option>
								<option>  TECHNOLOGY & VOCATIONAL EDUCATION</option>
								<option> URBAN & REGIONAL PLANNING</option>
								 
 								</select>	
  </div>
            </div>
             
              <li>
                <label for="answer">Question</label>
                <textarea   name="question" rows="8" cols="50"></textarea>
              </li>
			   <li>
                <label for="answer">Options A</label>
				<input type= "text" name = "option_a"/>
 </li>
 <label for="answer">Options B</label>
				<input type= "text" name = "option_b"/>
 </li>
 <label for="answer">Options C</label>
				<input type= "text" name = "option_c"/>
 </li>
 <label for="answer">Correct Option</label>
				<select name = "correct_option">
					<option>A</option>
					<option>B</option>
					<option>C</option>
				
					
				
				</select>
 </li>
              <li>
                <input type="submit" name="send"  value="Submit"  />
               </li>
            </ol>
          </form>
       
		 </div>
		 
	
		<table  style="float:right; margin-right:5%;    " class="content">
                            	<tr>
                                	<th>S.n.</th>
                                    <th>Question No</th>
                                    <th>Department</th>
                                    <th>Question</th>
                                    <th>Option A</th>
                                    <th>Option B</th>
                                    <th>Option C</th>
                                     <th>Date</th>
                                </tr>
                                <?php
									$query = mysqli_query($con,"select * from examination   ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$question_no = $row['question_no'];
											$department = $row['department'];
											$question = $row['question'];
											$option_a = $row['option_a'];
											$option_b = $row['option_b'];
											$option_c = $row['option_c'];
 											$date = $row['date'];
 										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $question_no; ?></td>
                                                <td><?php echo $department; ?></td>
                                                <td><?php echo $question; ?></td>
                                                <td><?php echo $option_a; ?></td>
                                                <td><?php echo $option_b; ?></td>
                                                <td><?php echo $option_c; ?></td>
                                                  <td><?php echo $date; ?></td>
                                                
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No Examination Yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>           

       	 
 
 </div>
 
</body>
</html>