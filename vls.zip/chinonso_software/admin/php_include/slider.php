<div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" />
		<span> Find possible solution to students whom because of distance to this institution and are unable to acquire knowledge that they need and also to bridge the gap between lecturers and students.  Since the system is virtual, that is there will be no physical contact between students, and their instructors, .
		</span></a>
		<a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" />
		<span> Bringing to limelight the economic and time constraints 
		</span></a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" />
		<span> because of nearness to institute and is unable to acquire knowledge that they need. Again, to provide students easier way to acquire any knowledge without been in the institute or with less difficulty.</span></a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>