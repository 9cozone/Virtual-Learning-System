 <div class="Quick">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="post" action="#">
            <span>
            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
            </span>
            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
          </form>
        </div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Quick</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">Sign Up</a></li>
            <li><a href="#">Login</a></li>
            <li><a href="#">Lecturers</a></li>
            <li><a href="#">Admin</a></li>
           
          </ul>
        </div>
        <div class="gadget">
          <h2 class="star"><span>Sponsors</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
         <li><a href="#">NYSC batch A senate list</a><br />
              All the eligible corp members should check their name in nysc portal</li>
            <li><a href="#">NYSC Batch B senate list</a><br />
              All the eligible corp members should check their name in nysc portal</li>   
			  <li><a href="#">Admission In Progress</a><br />
              2019 / 2020 admission in progress , the form is ready </li>
            <li><a href="#">UTM EXAMINATION DATE</a><br />
             All the aspiring student of ESUT are expected to be in school on time</li>
            <li><a href="#">Suspended students</a><br />
              Student that were cought practicing secret court activities</li>
            <li><a href="#">Why the VC should leave</a><br />
             All the student protest that the VC must leave the school for extorting, sexual molestation of students</li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>