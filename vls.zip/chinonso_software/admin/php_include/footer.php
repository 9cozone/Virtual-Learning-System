  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>Image</span> Gallery</h2>
        <a href="#"><img src="images/gal1.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal2.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal3.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal4.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal5.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal6.jpg" width="75" height="75" alt="" class="gal" /></a> </div>
      <div class="col c2">
        <h2><span>Services</span> Overview</h2>
        <p>Esut Virtual learning is an online learning system that enable people from all over the world to lear at the comfort of their home.  </p>
        <ul class="fbg_ul">
          <li><a href="#">Virtual learning system</a></li>
          <li><a href="#">Class Room</a></li>
          <li><a href="#">Onkine Assignments and Examination</a></li>        </ul>
      </div>
      <div class="col c3">
        <h2><span>Contact</span> Us</h2>
        <p>   Acquire the  knowledge at the comfort your home and with no risk all we need is your time</p>
        <p class="contact_info"> <span>Address:</span>ESUT Agbanni Enugu<br />
          <span>Telephone:</span> +234 08112111407<br />
          <span>FAX:</span> +234-81488699798<br />
          <span>Others:</span> +234-81488699798<br />
          <span>E-mail:</span> <a href="#">esutvls@gmail.com</a> </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">Copyright &copy; <a href="#">www.esut_vls.com</a>. All Rights Reserved</p>
      <p class="rf">Design by <a target="_blank" href="#">Chinonso</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
