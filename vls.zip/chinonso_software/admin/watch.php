 <?php
 include('php_include/check-login.php');
 include('php_include/connect.php');
 
	 
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
 
	<div >
      <div style="float:left;" class="menu_nav">
        <ul>
		
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>
      </div>
  <div class="article">
          <h2><span>Watch Videos</span></h2>
          <div class="clr"></div>
		  
	  
		  
		  
         </div>
		 
    <?php //User cliced on join
	 if(isset($_GET['id'])){
 $id = $_GET['id'];
 $query = mysqli_query($con,"select * from videos where id ='$id' ");
 
 while($row = mysql_fetch_array($query)){
	 $name_of_video= $row['name_of_video'];
	 $url= $row['url'];
	  $id = $row['id'];
 }
 	echo "You are watchiing ".$name_of_video."<br/>"; 
 	echo "<embed src='$url' height = '200' width ='200'> </embed>";
?>

<?php

	 " <video width='300' height='200' controls
	<source src='$url/<?php echo $name_of_video; ?>' type='video/mp4'>
	</video>"
	 } 
?>
		  
	
</div>
		 
</body>
</html>