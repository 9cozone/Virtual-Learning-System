 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>

<?php
	
if(isset($_GET['send'])){
 	$name = mysqli_real_escape_string($con,$_GET['name']);
  	$question = mysqli_real_escape_string($con,$_GET['question']);
	$email = mysqli_real_escape_string($con,$_GET['email']);
 	$date = date("y-m-d");
 
 	 
	
	
	if($name!='' && $question!=''&& $email!='' ){
				
 

			

		//Inset the value to pin request
		$query = mysqli_query($con,"insert into chat_room(`name`,`question`,`email`,`date_posted`) values( '$name`','$question','$email','$date')");
		if($query){
			echo '<script>alert("Your question  has been sent successfully");window.location.assign("hod.php");</script>';
		}
		else{
			//echo mysqli_error($con);
			echo '<script>alert("Unknown error occure.");window.location.assign("hod.php");</script>';
		}
	}
	else{
		echo '<script>alert("Please fill all the fields");</script>';
	}
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VIDEOS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
	<div class="mainbar">
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>           

      </div>
  <div   class="article">
            <form action="" method="GET" id="sendemail">
            <ol>
              <li>
                <label for="name">Name (required)</label>
                <input id="name" name="name" class="text" />
              </li>
              <li>
                <label for="email">Email Address (required)</label>
                <input id="email" name="email" class="text" />
              </li>
             
              <li>
                <label for="message">Your Question</label>
                <textarea id="message" name="question" rows="8" cols="50"></textarea>
              </li>
              <li>
                <input type="submit" name="send"  value="Submit" class="send" />
               </li>
            </ol>
          </form>
       
		 </div>
		 
		       	<table  style="float:left; clear:left; margin-left:5%;"  class="gadget">
                            	<tr>
                                	<th>S/N</th>
                                    <th>Question</th>
                                    <th>Answer</th>
                                     <th>Lectureer</th>
                                    <th>Date</th>
                                </tr>
                                <?php
									$query = mysqli_query($con,"select * from chat_room   ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$question = $row['question'];
											$answer = $row['answer'];
 											$lecturer = $row['name'];
											$date = $row['date_posted'];
										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $question; ?></td>
                                                <td><?php echo $answer; ?></td>
                                                <td><?php echo $lecturer; ?></td>
                                                 <td><?php echo $date; ?></td>
                                                
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No Coversation yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>           

       
</body>
</html>
		 
		 
 