<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>
      </div>

<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
