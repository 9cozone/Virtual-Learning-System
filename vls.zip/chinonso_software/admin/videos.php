 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>
<?php //User cliced on join
if(isset($_POST['send'])){
 
 	$department = mysqli_real_escape_string($con,$_POST['department']);
	$course_name = mysqli_real_escape_string($con,$_POST['course_name']);
	$course_code = mysqli_real_escape_string($con,$_POST['course_code']);
	$name_of_video =  $_FILES['file']['name'];
	$temp =   $_FILES['file']['tmp_name'];
	
	$lecturer_name = mysqli_real_escape_string($con,$_POST['lecturer_name']);
 
 
	$date_posted = mysqli_real_escape_string($con,$_POST['date_posted']);
	 
	$flag = 0;
	
	

 
	
	
	
	
	if($department!='' && $course_name!='' && $course_code!='' && 
	
	 $lecturer_name!='' && $date_posted!=''  ){
		//User filled all the fields.
		 
		 
					 
						$flag=1;
					 
				 
	}
	else{
		//check all fields are fill
		echo '<script>alert("Please fill all the fields.");</script>';
	}
	
	//Now we are heree
	//It means all the information is correct
	//Now we will save all the information
	if($flag==1){
		
			
//extract($_GET);
	move_uploaded_file($temp,"upload_videos/".$name_of_video);
	$url = "upload_videos/
$name_of_video";

	//Insert into User profile
		$query = mysqli_query($con,"insert into videos(`username`,`department`,`course_name`,`course_code`
		,`name_of_video`,`url`,`lecturer_name`,`date_posted` ) values('$username','$department','$course_name','$course_code'
		,'$name_of_video',
		'$url','$lecturer_name','$date_posted' )");

echo mysqli_error($con);
		
echo '<script>alert("Your Video was posted Succesfull");</script>';
	

}

	}
  
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
 
	<div >
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>
      </div>
  <div class="article">
          <h2><span>Post New Books</span></h2>
          <div class="clr"></div>
         </div>
		 
		 <div class="widget-content nopadding">
          <form action="videos.php" method="POST" enctype="multipart/form-data"  class="form-horizontal">
            <div class="control-group">
              <label class="control-label">Department</label>
              <div class="controls">
             						<select   name ="department" class="textbox" required>
								<option> ACCIDENT & EMERGENCY</option>
								<option> ACCOUNTANCY</option>
								<option>  ADULT & CONTINUING EDUCATION</option>
								<option> AGRICULTURAL & BIORESOURCE ENGINEERING</option>
								<option> AGRICULTURE ECONOMICS & EXTENSION</option>
								<option>  AGRONOMY & ECOLOGICAL MANAGEMENT </option>
								<option>  ANAESTHOLOGY</option>
								<option> ANATOMY</option>
								<option> ANIMAL/FISHERIES SCIENCE & MANAGEMENT</option>
								<option> APPLIED BIOCHEMISTRY</option>
								<option>  APPLIED BIOLOGY & BIOTECHNOLOGY</option>
								<option> APPLIED MICROBIOLOGY & BREWING</option>
								<option>  BANKING & FINANCE</option>
								<option>  BUILDING</option>
								<option> BUSINESS ADMINISTRATION</option>
								<option>  BUSINESS LAW</option>
								<option> CHEMICAL ENGINEERING</option>
								<option>  CIVIL ENGINEERING</option>
								<option> CLINICAL PHARMACY & BIOPHARMACEUTICS</option>
								<option> COMMUNITY MEDICINE</option>
								<option>  COMPUTER ENGINEERING</option>
								<option>  COMPUTER SCIENCE</option>
								<option>  COORPERATIVE & RURAL DEVELOPMENT</option>
								<option> ECONOMICS</option>
								<option>  EDUCATION FOUNDATION</option>
								<option>  EDUCATION MANAGEMENT</option>
								<option>  ELECTRICAL & ELECTRONICS ENGINEERING</option>
								<option>  ESTATE MANAGEMENT</option>
								<option>  FOOD SCIENCE & TECHNOLOGY</option>
								<option>  GEOGRAPHY & METEOROLOGY</option>
								<option>  GEOLOGY & MINING</option>
								<option>  GUIDANCE & COUNSELLING</option>
								<option> HAEMATOLOGY/IMMUNOLOGY</option>
								<option> HEALTH & PHYSICAL EDUCATION</option>
								<option>  HISTOPATHOLOGY</option>
								<option>  HUMAN PHYSIOLOGY</option>
								<option>  INDUSTRIAL CHEMISTRY</option>
								<option>  INDUSTRIAL MATHEMATICS & APPLIED STATISTICS</option>
								<option> INDUSTRIAL PHYSICS</option>
								<option>  INSURANCE & RISK MANAGEMENT</option>
								<option>  INTERNAL MEDICINE</option>
								<option>  INTERNATIONAL LAW & JURISPRUDENCE</option>
								<option> LIBRARY & INFORMATION SCIENCE</option>
								<option>  MARKETING</option>
								<option>  MASS COMMUNICATION</option>
								<option> MATHEMATICS & COMPUTER EDUCATION</option>
								<option> MECHANICAL & PRODUCTION ENGINEERING</option>
								<option>  MEDICAL BIOCHEMISTRY</option>
								<option>  MEDICAL LABORATORY SCIENCES</option>
								<option>  OBSTETRICS & GYNAECOLOGY</option>
								<option>  OPHTHALMOLOGY</option>
								<option>  ORTOLARYNGOLOGY</option>
								<option> PAEDIATRICS</option>
								<option>  PATHOLOGY</option>
								<option>  PHARMACEUTICAL CHEMISTRY</option>
								<option> PHARMACEUTICS & PHARMACEUTICAL TECHNOLOGY</option>
								<option>  PHARMACOGNOSY</option>
								<option>  PHARMACOLOGY</option>
								<option>  PHARMACOLOGY & THERAPEUTICS</option>
								<option>  POLITICAL SCIENCE</option>
								<option>  PRIVATE & PROPERTY LAW</option>
								<option> PSYCHOLOGY</option>
								<option>  PUBLIC ADMINISTRATION</option>
								<option>  PUBLIC LAW</option>
								<option>  QUANTITY SURVEYING</option>
								<option>  RADIOLOGY</option>
								<option>  SCIENCE & COMPUTER EDUCATION</option>
								<option>  SOCIOLOGY & ANTHROPOLOGY</option>
								<option> SURGERY</option>
								<option> SURVEYING & GEOINFORMATICS</option>
								<option>  TECHNOLOGY & VOCATIONAL EDUCATION</option>
								<option> URBAN & REGIONAL PLANNING</option>
								 
 								</select>	
  </div>
            </div>
              <div class="control-group">
              <label class="control-label">Course Name</label>
			    <input type="text" name="course_name" />
              
            </div>
			<div class="control-group">
              <label class="control-label">Course Code</label>
			    <input type="text" name="course_code" />
              
            </div>
		 
			<div class="control-group">
              <label class="control-label">Lecturer"s Name</label>
			    <input type="text" name="lecturer_name" />
              
            </div>
			
			<div class="control-group">
              <label class="control-label">Date Of posting</label>
			    <input type="date" name="date_posted" />
              
            </div>
			<div class="control-group">
              <label class="control-label">Upload Video</label>
			    <input type="file" name="file" />
              
            </div>
			<div class="control-group">
 			    <input type="submit" name="send" value="Post video"/>
              
            </div>
			 
          </form>
        </div>
		
		       	<table  class="table table-striped table-bordered">
                            	<tr>
                                	<th>S.n.</th>
                                    <th>Department</th>
                                    <th>Course Name </th>
                                    <th>Course Code</th>
                                    <th>Watch Video</th>
                                    <th>Lecturer's Name</th>
n                                    <th>Date Posted</th>
                                 </tr>
                                <?php
									$query = mysqli_query($con,"select * from videos    ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$department = $row['department'];
											$course_name = $row['course_name'];
											$course_code = $row['course_code'];
											$name_of_video = $row['name_of_video'];
											$lecturer_name = $row['lecturer_name'];
										
											$date_posted = $row['date_posted'];
										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $department; ?></td>
                                                <td><?php echo $course_name; ?></td>
                                                <td><?php echo $course_code; ?></td>
                                                 <td>
												
												 <?php echo "<a href ='watch.php?id=$id'>$name_of_video</a><br/>";		?>
												
												
												</td>
                                                <td><?php echo $lecturer_name; ?></td>
                                                <td><?php echo $date_posted; ?></td>
                                                
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No video posted in this departments yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>
       
</div>
		 
</body>
</html>