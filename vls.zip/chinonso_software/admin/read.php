 <?php
 include('php_include/check-login.php');
 
	 
 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
 
	<div >
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>
      </div>
  <div class="article">
          <h2><span>Watch Videos</span></h2>
          <div class="clr"></div>
		  
	  
		  
		  
         </div>
		 
    <?php //User cliced on join
	mysql_connect("localhost","root","");
	mysql_select_db("esut_vls");
 if(isset($_GET['id'])){
 $id = $_GET['id'];
 $query = mysqli_query("select * from `books` where id ='$id' ");
 
 while($row = mysql_fetch_assoc($query)){
	 $name_of_book= $row['name_of_book'];
		$url= $row['url'];
	  $id = $row['id'];
 }
 	echo "You are Reading ".$name_of_book."<br/>"; 
		
	echo "<a download="<?php echo $file[$a]?>" href="uploads/<?php echo $file[$a]?>"> <?php echo $file[$a]?></a>";

	 
 }	 
?>
		  
	
</div>
		 
</body>
</html>