<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
      <div class="content">
    <div class="content_resize">
      <?php
session_start();
require('php_include/connect.php');
$username = mysqli_real_escape_string($con,$_POST['username']);
$password = mysqli_real_escape_string($con,$_POST['password']);

$query = mysqli_query($con,"select * from admin where username='$username' and password='$password'");
if(mysqli_num_rows($query)>0){
	$_SESSION['username'] = $username;
	$_SESSION['id'] = session_id();
	$_SESSION['login_type'] = "admin";
	
	echo '<script>alert("Login Success.");window.location.assign("home.php");</script>';
	
}
else{
	echo '<script>alert(" Username or password is worng.");window.location.assign("login.php");</script>';
}

?>

<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
