<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
 
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Excellent Solution</span> For Learning</h2>
          <p class="infopost">Posted <span class="date">on 11 Oct 2019</span> by <a href="#">Admin</a>  </p>
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="178" height="185" alt="" class="fl" /></div>
          <div class="post_content">
            <p>Esut Virtual learning is an online learning system that enable people from all over the world to lear at the comfort of their home.  
			Are you tired of taking the risk of transporting or spending much on the transportation means 
			All in the name of studing course of you choice in Esut.</p>
            <p><strong>Enugu State University of Science and Technology (ESUT) has 
			come up it her E-Learning system which is also know as 	Virtual Learning System (VLS)</strong> 
			Now learn at the comfort of your home and let ESUT VLS access you by 
			their constant online assignment and Examination </p>
            <p class="spec"><a href="#" class="rm">Read more</a> <a href="#" class="com">Comments <span>11</span></a></p>
          </div>
          <div class="clr"></div>
        </div>
        <div class="article">
          <h2><span>We'll Make Sure Learning</span> Become Easy for you</h2>
          <p class="infopost">Posted <span class="date">on 29 sep 2018</span> by <a href="#">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">learn</a>, <a href="#">internet</a></p>
          <div class="clr"></div>
          <div class="img"><img src="images/img2.jpg" width="178" height="185" alt="" class="fl" /></div>
          <div class="post_content">
            <p>Unlike other Virtual learning system of other school
				ESUT VLS is unique in operation because our lectures are easily 
				accessible.
			<a href="#">  Communication is the greatest link of learning</a>  
			Out of experience we find out the without quality communication there is no way learning 
			could be effectively be delivered or properly enhanced</p>
            <p><strong> Why not make the right choice today and live to celebrate your experience with ESUT Virtual Learning system.</strong> 
			Education has been facing the challenge of not meeting up to the 
			expectations and demand of student in relation to proper accessment and grading of student perfumance.</p>
            <p class="spec"><a href="#" class="rm">Read more</a> <a href="#" class="com">Comments <span>7</span></a></p>
          </div>
          <div class="clr"></div>
        </div>
        <p class="pages"><small>Page 1 of 2</small> <span>1</span> <a href="#">2</a> <a href="#">&raquo;</a></p>
      </div>
     

<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
