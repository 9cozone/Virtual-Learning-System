 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VIDEOS</title>
<?php include('php_include/nav.php');?>
  <div class="content">
    <div class="content_resize">
	<div class="mainbar">
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>
      </div>
  <div class="article">
          <h2><span>Videos</span></h2>
          <div class="clr"></div>
         </div>
		 
		 
		  	<table  class="table table-striped table-bordered">
                            	<tr>
                                	<th>S.n.</th>
                                    <th>Department</th>
                                    <th>Course Name </th>
                                    <th>Course Code</th>
                                    <th>Watch Video</th>
                                    <th>Lecturer's Name</th>
n                                    <th>Date Posted</th>
                                 </tr>
                                <?php
									$query = mysqli_query($con,"select * from videos    ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$department = $row['department'];
											$course_name = $row['course_name'];
											$course_code = $row['course_code'];
											$name_of_video = $row['name_of_video'];
											$lecturer_name = $row['lecturer_name'];
										
											$date_posted = $row['date_posted'];
										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $department; ?></td>
                                                <td><?php echo $course_name; ?></td>
                                                <td><?php echo $course_code; ?></td>
                                                 <td>
												
												 <?php echo "<a href ='watch.php?id=$id'>$name_of_video</a><br/>";		?>
												
												
												</td>
                                                <td><?php echo $lecturer_name; ?></td>
                                                <td><?php echo $date_posted; ?></td>
                                                
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No video posted in this departments yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>
       
</div>
		 
		 
<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
