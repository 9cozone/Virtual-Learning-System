<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VLS</title>
<?php include('php_include/nav.php');?>
 
  <div class="content">
    <div class="content_resize">
      <div class="content">
    <div class="content_resize">
        <div class="mainbar">
        <div class="article">
          <h2><span>About to</span> ESUT VIRTUAL LEARNING SYSTEM</h2>
          <div class="clr"></div>
          <p><strong> ESUT as one of the famous school in the south east of Nigeria has been rated as the best in online virtual e-learning system has so many hybrid of online functionalities</strong></p>
          <p>You can now do the following with our online VLS , Online examination and Assignments </p>
        </div>
        <div class="article">
          <h2><span>Our</span> Mission</h2>
          <div class="clr"></div>
          <p><strong> To Ensure the total revitalization of the online learning system in Nigeria.</strong></p>
          <p>    Find possible solution to students whom because of distance to this institution and are unable to acquire knowledge that they need and also to bridge the gap between lecturers and students. Since the system is virtual, that is there will be no physical contact between students, and their instructors,   </p>
          <p>Bringing to limelight the economic and time constraints </p>
        </div>
      </div>
    

<?php include('php_include/side_bar.php');?>
<?php include('php_include/footer.php');?>
