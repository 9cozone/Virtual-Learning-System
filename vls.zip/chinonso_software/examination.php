 <?php
 include('php_include/check-login.php');
include('php_include/connect.php');
$username = $_SESSION['username'];
	 
 ?>

<?php
	
if(isset($_POST['send'])){
	$question_no = mysqli_real_escape_string($con,$_POST['question_no']);

	$question = mysqli_real_escape_string($con,$_POST['question']);
	$option_a = mysqli_real_escape_string($con,$_POST['option_a']);
	$option_b = mysqli_real_escape_string($con,$_POST['option_b']);
	$option_c = mysqli_real_escape_string($con,$_POST['option_c']);
	$correct_option = mysqli_real_escape_string($con,$_POST['correct_option']);
	$option = mysqli_real_escape_string($con,$_POST['option']);
   	$date = date("y-m-d");
 
 	 
	
	
	if($option!=''    ){
				

 if($option==$correct_option){
 
	$mark =5;
 

 }else{
		$mark=0;


 }
$sum =mysqli_query($con, "select * from examination where username='$username '");
while($row=mysqli_fetch_array($sum)){
	$score =$row['score'];
$total= $score + $mark;
			

		//Inset the value to pin request
		$query = mysqli_query($con,"update  examination set score ='$total' WHERE usernae='$username'  ");
		if($query){
			echo '<script>alert("Answer submited successfully");window.location.assign("examination.php");</script>';
		}
		else{
			//echo mysqli_error($con);
			echo '<script>alert("Unknown error occure.");window.location.assign("examination.php");</script>';
		}
	}
}
	else{
		echo '<script>alert("Please fill all the fields");</script>';
	}
	
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ESUT VIDEOS</title>
<?php include('php_include/nav.php');?>
  
	<div  >
      <div style="float:left;" class="menu_nav">
        <ul>
          <li  ><a href="books.php"><span>Books</span></a></li>
          <li><a href="videos.php"><span>Videos</span></a></li>
          <li><a href="hod.php"><span>HOD</span></a></li>
          <li><a href="assignment.php"><span>Assignment</span></a></li>
          <li><a href="examination.php"><span>Examination</span></a></li>
        </ul>           

      </div>
 	       
 
		 
	
		<table  style="float:right; margin-right:5%;    " class="content">
                            	<tr>
                                	<th>S.n.</th>
                                    <th>Question No</th>
                                    <th>Question</th>
									<th>Options</th>
                                     <th>Date</th>
                                </tr>
                                <?php
									$query = mysqli_query($con,"select * from examination");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$questino_no = $row['question_no'];
											$question = $row['question'];
											$option_a = $row['option_a'];
											$option_b = $row['option_b'];
											$option_c = $row['option_c'];
											$correct_option = $row['correct_option'];

 											$date = $row['date'];
 										?>
                                        	<tr>
											<form action ="#" method ="POST">
                                            	<td><?php echo $i; ?></td>
                                                <td><?php echo $questino_no; ?></td>
                                                <td><?php echo $question; ?></td>
												<td><?php echo $option_a; ?></td>
												<td><?php echo $option_b; ?></td>
												<td><?php echo $option_c; ?></td>
												<td>  A<input type = "radio" name="option" value="A"/>
												B<input type = "radio" name="option" value="B"/>
												C<input type = "radio" name="option" value="C"/>
												
												<input type = "hidden" name="question_no" value="<?php $questino_no ?>"/>
												<input type = "hidden" name="question" value="<?php $questino ?>"/>
												<input type = "hidden" name="option_a" value="<?php $option_a?>"/>
												<input type = "hidden" name="option_b" value="<?php $option_b ?>"/>
												<input type = "hidden" name="option_c" value="<?php $option_c ?>"/>
												<input type = "hidden" name="correct_option" value="<?php $correct_option ?>"/>
												
												
												
												
												 </td>
												 <td> <input type ="submit" name="send" value="Submit"/> </td>
												   <td><?php echo $date; ?></td>
                                               </form> 
                                            </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="6" align="center">No examination Yet</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>           

       	 
 
 </div>
 
</body>
</html>