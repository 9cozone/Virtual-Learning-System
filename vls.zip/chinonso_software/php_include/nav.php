<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-georgia.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li  ><a href="index.php"><span>Home Page</span></a></li>
          <li><a href="login.php"><span>VLS</span></a></li>
          <li><a href="about.php"><span>About Us</span></a></li>
          <li><a href="admin.php"><span>Support</span></a></li>
          <li><a href="contact.php"><span>Contact Us</span></a></li>
        </ul>
      </div>
      <div class="logo">
        <h1><a href="index.php">ESUT<span>VLS</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" />
		<span> Find possible solution to students whom because of distance to this institution and are unable to acquire knowledge that they need and also to bridge the gap between lecturers and students.  Since the system is virtual, that is there will be no physical contact between students, and their instructors, .
		</span></a>
		<a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" />
		<span> Bringing to limelight the economic and time constraints 
		</span></a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" />
		<span> because of nearness to institute and is unable to acquire knowledge that they need. Again, to provide students easier way to acquire any knowledge without been in the institute or with less difficulty.</span></a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>